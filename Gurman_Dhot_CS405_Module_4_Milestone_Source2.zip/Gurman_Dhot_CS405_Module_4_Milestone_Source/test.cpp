// Uncomment the next line to use precompiled headers
#include "pch.h"
// Uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"

#include <cassert>
#include <cstdlib>
#include <ctime>
#include <memory>
#include <stdexcept>
#include <vector>

// The global test environment setup and tear down.
// No changes are required here for the milestone tests.
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Initialize the random seed before tests run.
    void SetUp() override
    {
        srand(static_cast<unsigned int>(time(nullptr)));
    }

    void TearDown() override {}
};

// Test fixture that provides a fresh collection for each test.
class CollectionTest : public ::testing::Test
{
protected:
    // Smart pointer that owns the vector used by each test.
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    {
        // Create a new collection before each test.
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    {
        // Remove any remaining elements, then release the pointer.
        collection->clear();
        collection.reset(nullptr);
    }

    // Add random values from 0 to 99 to the collection.
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
        {
            collection->push_back(rand() % 100);
        }
    }
};

// Use ASSERT when a failed condition should stop the current test.
// Use EXPECT when the test can continue and report additional failures.

// Provided test: verify that the smart pointer is created successfully.
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    ASSERT_TRUE(collection);
    ASSERT_NE(collection.get(), nullptr);
}

// Provided test: verify that a newly created collection is empty.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0u);
}

/*
 * Intentionally failing demonstration test from the starter file.
 * It is commented out so the completed milestone test run can pass.
 *
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}
 */

// 1. Verify that one value can be added to an empty collection.
TEST_F(CollectionTest, AddingSingleValueChangesSizeFromZeroToOne)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0u);

    add_entries(1);

    EXPECT_FALSE(collection->empty());
    EXPECT_EQ(collection->size(), 1u);
}

// 2. Verify that five values can be added to the collection.
TEST_F(CollectionTest, AddingFiveValuesResultsInSizeFive)
{
    ASSERT_TRUE(collection->empty());

    add_entries(5);

    EXPECT_FALSE(collection->empty());
    EXPECT_EQ(collection->size(), 5u);
}

// 3. Verify max_size() is never smaller than size() for several collection sizes.
TEST_F(CollectionTest, MaxSizeIsAtLeastCurrentSizeForCommonEntryCounts)
{
    const int entryCounts[] = { 0, 1, 5, 10 };

    for (int entryCount : entryCounts)
    {
        collection->clear();
        if (entryCount > 0)
        {
            add_entries(entryCount);
        }

        EXPECT_GE(collection->max_size(), collection->size());
        EXPECT_EQ(collection->size(), static_cast<std::vector<int>::size_type>(entryCount));
    }
}

// 4. Verify capacity() is never smaller than size() for several collection sizes.
TEST_F(CollectionTest, CapacityIsAtLeastCurrentSizeForCommonEntryCounts)
{
    const int entryCounts[] = { 0, 1, 5, 10 };

    for (int entryCount : entryCounts)
    {
        collection->clear();
        if (entryCount > 0)
        {
            add_entries(entryCount);
        }

        EXPECT_GE(collection->capacity(), collection->size());
        EXPECT_EQ(collection->size(), static_cast<std::vector<int>::size_type>(entryCount));
    }
}

// 5. Verify resize() can increase the number of elements.
TEST_F(CollectionTest, ResizeToLargerValueIncreasesCollectionSize)
{
    add_entries(5);
    const auto originalSize = collection->size();

    collection->resize(10);

    EXPECT_GT(collection->size(), originalSize);
    EXPECT_EQ(collection->size(), 10u);
}

// 6. Verify resize() can decrease the number of elements.
TEST_F(CollectionTest, ResizeToSmallerValueDecreasesCollectionSize)
{
    add_entries(10);
    const auto originalSize = collection->size();

    collection->resize(5);

    EXPECT_LT(collection->size(), originalSize);
    EXPECT_EQ(collection->size(), 5u);
}

// 7. Verify resize(0) reduces the collection to an empty state.
TEST_F(CollectionTest, ResizeToZeroEmptiesCollection)
{
    add_entries(5);
    ASSERT_FALSE(collection->empty());

    collection->resize(0);

    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0u);
}

// 8. Verify clear() removes every element from the collection.
TEST_F(CollectionTest, ClearRemovesAllElements)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5u);

    collection->clear();

    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0u);
}

// 9. Verify erase(begin, end) removes the entire range.
TEST_F(CollectionTest, EraseFullRangeRemovesAllElements)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5u);

    collection->erase(collection->begin(), collection->end());

    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0u);
}

// 10. Verify reserve() increases capacity without changing logical size.
TEST_F(CollectionTest, ReserveIncreasesCapacityWithoutChangingSize)
{
    add_entries(5);
    const auto originalSize = collection->size();
    const auto originalCapacity = collection->capacity();
    const auto requestedCapacity = originalCapacity + 10;

    collection->reserve(requestedCapacity);

    EXPECT_EQ(collection->size(), originalSize);
    EXPECT_GT(collection->capacity(), originalCapacity);
    EXPECT_GE(collection->capacity(), requestedCapacity);
}

// 11. Negative test: at() must throw when the index is outside the collection.
TEST_F(CollectionTest, AtThrowsOutOfRangeWhenIndexEqualsSize)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5u);

    EXPECT_THROW(collection->at(collection->size()), std::out_of_range);
}

// 12. Student-created positive test: verify vector insertion order is preserved.
TEST_F(CollectionTest, PushBackPreservesInsertionOrder)
{
    collection->push_back(10);
    collection->push_back(20);
    collection->push_back(30);

    ASSERT_EQ(collection->size(), 3u);
    EXPECT_EQ(collection->at(0), 10);
    EXPECT_EQ(collection->at(1), 20);
    EXPECT_EQ(collection->at(2), 30);
}

// 13. Student-created negative test: reading from an empty vector with at() must fail safely.
TEST_F(CollectionTest, AtThrowsOutOfRangeWhenCollectionIsEmpty)
{
    ASSERT_TRUE(collection->empty());

    EXPECT_THROW(collection->at(0), std::out_of_range);
}
