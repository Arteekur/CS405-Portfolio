// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
    //  even though it is a constant and the compiler buffer overflow checks are on.
    //  You need to modify this method to prevent buffer overflow without changing the account_number
    //  variable, and its position in the declaration. It must always be directly before the variable used for input.
    //  You must notify the user if they entered too much data.

    const std::string account_number = "CharlieBrown42";
    char user_input[20];

    std::cout << "Enter a value: ";

    // getline limits the amount of data written to the 20-character buffer.
    // The buffer can safely hold 19 characters plus the null terminator.
    std::cin.getline(user_input, sizeof(user_input));

    // If the input is too large, getline sets the input stream to a failed state.
    if (std::cin.fail())
    {
        std::cout << "Error: Input is too long. Please enter no more than 19 characters."
                  << std::endl;
    }
    else
    {
        std::cout << "You entered: " << user_input << std::endl;
    }

    // The account number remains unchanged even when oversized input is attempted.
    std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
