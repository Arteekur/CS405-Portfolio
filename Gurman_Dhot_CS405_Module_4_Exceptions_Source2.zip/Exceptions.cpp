// Exceptions.cpp : Module Four Exceptions Activity
// Demonstrates standard exceptions, a custom exception, targeted catch blocks,
// and a final catch-all handler so the program fails safely instead of crashing.

#include <iostream>
#include <exception>
#include <stdexcept>

// Custom exception class derived from std::exception, as required by the activity.
class CustomApplicationException : public std::exception
{
public:
    const char* what() const noexcept override
    {
        return "Custom application logic reported a controlled failure.";
    }
};

bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Throw a standard C++ exception so the caller can demonstrate handling it.
    throw std::runtime_error(
        "A standard runtime exception occurred in the extended application logic."
    );
}

void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    // Wrap code that may throw and catch standard-library exceptions by reference.
    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& exception)
    {
        std::cout << "Standard exception caught in custom application logic: "
                  << exception.what() << std::endl;
    }

    // The function continues after the standard exception was handled.
    std::cout << "Continuing Custom Application Logic after handling std::exception."
              << std::endl;

    // Throw the custom exception so main() can catch it explicitly.
    throw CustomApplicationException();
}

float divide(float num, float den)
{
    // Prevent undefined/invalid application behavior by rejecting a zero denominator.
    if (den == 0.0f)
    {
        throw std::domain_error("Division by zero is not allowed.");
    }

    return (num / den);
}

void do_division() noexcept
{
    // Because this function is noexcept, the exception from divide() must be handled here.
    // Catch only std::domain_error, which is the exact exception type divide() throws.
    try
    {
        float numerator = 10.0f;
        float denominator = 0.0f;

        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator
                  << ") = " << result << std::endl;
    }
    catch (const std::domain_error& exception)
    {
        std::cout << "Division exception caught: " << exception.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // Catch exceptions from most specific to most general.
    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomApplicationException& exception)
    {
        std::cout << "Custom exception caught in main: "
                  << exception.what() << std::endl;
    }
    catch (const std::exception& exception)
    {
        std::cout << "Standard exception caught in main: "
                  << exception.what() << std::endl;
    }
    catch (...)
    {
        // Final safety net for an exception type that is not derived from std::exception.
        std::cout << "An unknown exception was caught in main." << std::endl;
    }

    std::cout << "Program finished safely." << std::endl;
    return 0;
}
