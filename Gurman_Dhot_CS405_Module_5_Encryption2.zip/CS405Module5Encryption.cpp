// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cassert>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>

/// <summary>
/// Encrypt or decrypt a source string using the provided key.
/// XOR is reversible, so the same function is used for both operations.
/// </summary>
/// <param name="source">Input string to process</param>
/// <param name="key">Key to use in encryption/decryption</param>
/// <returns>Transformed string</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    // Store lengths once so they do not need to be recalculated in the loop.
    const auto key_length = key.length();
    const auto source_length = source.length();

    // Validate required input.
    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // XOR each source character with a repeating character from the key.
    for (size_t i = 0; i < source_length; ++i)
    {
        output[i] = source[i] ^ key[i % key_length];
    }

    // Encryption/decryption must not change the size of the data.
    assert(output.length() == source_length);

    return output;
}

/// <summary>
/// Reads the complete contents of a text file into a string.
/// </summary>
std::string read_file(const std::string& filename)
{
    std::ifstream input_file(filename, std::ios::binary);
    if (!input_file)
    {
        throw std::runtime_error("Unable to open input file: " + filename);
    }

    std::ostringstream buffer;
    buffer << input_file.rdbuf();
    return buffer.str();
}

std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // Find the first newline.
    const size_t pos = string_data.find('\n');
    if (pos != std::string::npos)
    {
        student_name = string_data.substr(0, pos);

        // Remove a carriage return when reading a Windows CRLF text file.
        if (!student_name.empty() && student_name.back() == '\r')
        {
            student_name.pop_back();
        }
    }

    return student_name;
}

/// <summary>
/// Saves metadata followed by the supplied data using the required format.
/// </summary>
void save_data_file(const std::string& filename,
    const std::string& student_name,
    const std::string& key,
    const std::string& data)
{
    std::ofstream output_file(filename, std::ios::binary);
    if (!output_file)
    {
        throw std::runtime_error("Unable to create output file: " + filename);
    }

    // Get the current local date for line 2 of the required output format.
    const std::time_t now = std::time(nullptr);
    std::tm local_time{};

#ifdef _WIN32
    localtime_s(&local_time, &now);
#else
    localtime_r(&now, &local_time);
#endif

    // Required file format:
    // Line 1: student name
    // Line 2: timestamp (yyyy-mm-dd)
    // Line 3: key used
    // Line 4+: data
    output_file << student_name << '\n';
    output_file << std::put_time(&local_time, "%Y-%m-%d") << '\n';
    output_file << key << '\n';
    output_file.write(data.data(), static_cast<std::streamsize>(data.size()));
}

int main()
{
    std::cout << "Encryption Decryption Test!" << std::endl;

    // Input file format:
    // Line 1: <student name>
    // Line 2: <Lorem Ipsum Generator website used>
    // Lines 3+: <three paragraphs of generated text>

    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrytpteddatafile.txt";
    const std::string key = "password";

    try
    {
        const std::string source_string = read_file(file_name);

        // Get the student name from the first line of the data file.
        const std::string student_name = get_student_name(source_string);

        // Encrypt the source data and save the encrypted result.
        const std::string encrypted_string = encrypt_decrypt(source_string, key);
        save_data_file(encrypted_file_name, student_name, key, encrypted_string);

        // XOR the encrypted data with the same key to restore the original data.
        const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);
        save_data_file(decrypted_file_name, student_name, key, decrypted_string);

        std::cout << "Read File: " << file_name
            << " - Encrypted To: " << encrypted_file_name
            << " - Decrypted To: " << decrypted_file_name << std::endl;
    }
    catch (const std::exception& error)
    {
        std::cerr << "Error: " << error.what() << std::endl;
        return 1;
    }

    // Submit input file, encrypted file, decrypted file, source code file, and key used.
    return 0;
}
